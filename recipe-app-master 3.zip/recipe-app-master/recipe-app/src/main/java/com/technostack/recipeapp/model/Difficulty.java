package com.technostack.recipeapp.model;

public enum Difficulty {
	EASY, MODERATE, HARD
}
