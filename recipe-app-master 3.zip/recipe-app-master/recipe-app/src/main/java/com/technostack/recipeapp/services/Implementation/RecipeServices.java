package com.technostack.recipeapp.services.Implementation;

import java.util.Set;

import com.technostack.recipeapp.model.Recipe;

public interface RecipeServices {
	Set<Recipe> getRecipes();
}
